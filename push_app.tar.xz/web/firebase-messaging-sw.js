importScripts("https://www.gstatic.com/firebasejs/10.7.1/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/10.7.1/firebase-messaging-compat.js");

firebase.initializeApp({
  apiKey: "AIzaSyB_UJJY-ivFJEQdBGIHh6LQwTRpGWiI48Q",
  authDomain: "notificaciones-e1052.firebaseapp.com",
  projectId: "notificaciones-e1052",
  storageBucket: "notificaciones-e1052.firebasestorage.app",
  messagingSenderId: "876965165105",
  appId: "1:876965165105:web:e6d417261ee8364ff9fd10",
  measurementId: "G-63T6T5RSHM"
});

const messaging = firebase.messaging();
